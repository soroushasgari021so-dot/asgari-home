# ASGARI HOME – اتصال اولیه به Supabase

این بسته برای مرحله اتصال اولیه اپ اندروید به پروژه Supabase است.

## ساخت APK در GitHub Actions
در مخزن GitHub دو Repository Secrets تعریف کنید:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY` (مقدار Publishable key که با `sb_publishable_` شروع می‌شود)

در workflow فرمان build باید این دو مقدار را به صورت `--dart-define` به Flutter بدهد. هرگز از `service_role` یا `secret key` در برنامه موبایل استفاده نکنید.

## نکته دیتابیس
این نسخه از جدول‌های `public_listings` و `admin_users` استفاده می‌کند. تابع `is_admin()` و سیاست‌های RLS باید مطابق SQL اجراشده در پروژه باشند. جدول `admin_users` باید شامل UUID مدیر باشد. این برنامه در این مرحله فقط آگهی‌های عمومی را می‌خواند و ورود مدیر را اعتبارسنجی می‌کند؛ فرم‌های کامل مدیریت املاک هنوز در مرحله بعد توسعه داده می‌شوند.
