
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const gold = Color(0xFFD4AF37);
const black = Color(0xFF111111);

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (supabaseUrl.isNotEmpty && supabaseKey.isNotEmpty) {
    await Supabase.initialize(
      url: supabaseUrl,
      anonKey: supabaseKey,
    );
  }

  runApp(const AsgariHomeApp());
}

class AsgariHomeApp extends StatelessWidget {
  const AsgariHomeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'املاک عسگری',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F5EF),
        colorScheme: ColorScheme.fromSeed(seedColor: gold),
        appBarTheme: const AppBarTheme(
          backgroundColor: black,
          foregroundColor: gold,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('املاک عسگری')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: black,
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('ASGARI HOME',
                      style: TextStyle(color: gold, fontSize: 14)),
                  SizedBox(height: 12),
                  Text('خانه‌ی مناسب خود را پیدا کنید',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      )),
                  SizedBox(height: 8),
                  Text('خرید و فروش • رهن و اجاره',
                      style: TextStyle(color: Colors.white70)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            ActionTile(
              icon: Icons.home_work_outlined,
              title: 'مشاهده آگهی‌ها',
              subtitle: 'فایل‌های منتشرشده املاک',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ListingsPage(),
                ),
              ),
            ),
            ActionTile(
              icon: Icons.admin_panel_settings_outlined,
              title: 'ورود مدیران',
              subtitle: 'بخش خصوصی مدیریت دفتر',
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const LoginPage(),
                ),
              ),
            ),
            const SizedBox(height: 25),
            const Text('ارتباط با املاک عسگری',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 10),
            const SelectableText(
              'تماس: 09363882379\nتلگرام: @amlak_asgari',
            ),
          ],
        ),
      ),
    );
  }
}

class ActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const ActionTile({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        onTap: onTap,
        leading: Icon(icon, color: gold, size: 30),
        title: Text(title,
            style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_left),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    if (supabaseUrl.isEmpty || supabaseKey.isEmpty) {
      showMessage('تنظیمات اتصال به سرور انجام نشده است.');
      return;
    }

    setState(() => loading = true);

    try {
      final client = Supabase.instance.client;

      final response = await client.auth.signInWithPassword(
        email: email.text.trim(),
        password: password.text,
      );

      final user = response.user;
      if (user == null) {
        throw Exception('ورود انجام نشد.');
      }

      final admin = await client
          .from('admin_users')
          .select('user_id')
          .eq('user_id', user.id)
          .maybeSingle();

      if (!mounted) return;

      if (admin == null) {
        await client.auth.signOut();
        showMessage('این حساب دسترسی مدیریت ندارد.');
        return;
      }

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => const AdminPage(),
        ),
      );
    } catch (e) {
      showMessage('خطا در ورود: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ورود مدیران')),
        body: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              TextField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'ایمیل مدیر',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: password,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'رمز عبور',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: loading ? null : login,
                  child: Text(loading ? 'در حال بررسی...' : 'ورود'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});

  Future<void> logout(BuildContext context) async {
    await Supabase.instance.client.auth.signOut();
    if (context.mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const HomePage()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('پنل مدیریت املاک عسگری')),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.verified_user, size: 60, color: gold),
              const SizedBox(height: 15),
              const Text('ورود مدیر با موفقیت انجام شد'),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => logout(context),
                child: const Text('خروج از حساب'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ListingsPage extends StatefulWidget {
  const ListingsPage({super.key});

  @override
  State<ListingsPage> createState() => _ListingsPageState();
}

class _ListingsPageState extends State<ListingsPage> {
  late Future<List<Map<String, dynamic>>> listings;

  @override
  void initState() {
    super.initState();
    listings = loadListings();
  }

  Future<List<Map<String, dynamic>>> loadListings() async {
    if (supabaseUrl.isEmpty || supabaseKey.isEmpty) {
      throw Exception('تنظیمات اتصال به سرور انجام نشده است.');
    }

    final data = await Supabase.instance.client
        .from('public_listings')
        .select()
        .eq('is_published', true)
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(data);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('آگهی‌های املاک')),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: listings,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            if (snapshot.hasError) {
              return Center(
                child: Text('خطا در دریافت آگهی‌ها:\n${snapshot.error}'),
              );
            }

            final items = snapshot.data ?? [];

            if (items.isEmpty) {
              return const Center(child: Text('در حال حاضر آگهی منتشرشده‌ای وجود ندارد.'));
            }

            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];
                return Card(
                  child: ListTile(
                    title: Text(item['title']?.toString() ?? 'بدون عنوان'),
                    subtitle: Text(
                      '${item['property_type'] ?? ''} • '
                      '${item['transaction_type'] ?? ''}\n'
                      '${item['address'] ?? ''}',
                    ),
                    isThreeLine: true,
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
